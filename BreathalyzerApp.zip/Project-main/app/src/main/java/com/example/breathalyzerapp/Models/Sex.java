package com.example.breathalyzerapp.Models;

public enum Sex {
    MALE,
    FEMALE
}
